"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResponseDTO = void 0;
class ResponseDTO {
    constructor(status, data) {
        this.status = status;
        this.data = data;
    }
}
exports.ResponseDTO = ResponseDTO;
//# sourceMappingURL=response.dto.js.map