"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Token = void 0;
class Token {
}
exports.Token = Token;
//# sourceMappingURL=token.dto.js.map