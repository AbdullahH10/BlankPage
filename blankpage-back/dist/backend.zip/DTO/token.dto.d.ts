export declare class Token {
    userId: string;
    token: string;
}
