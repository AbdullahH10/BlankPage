export declare class UserDTO {
    userName: string;
    password: string;
}
