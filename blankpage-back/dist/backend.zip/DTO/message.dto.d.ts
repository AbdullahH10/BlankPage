export declare class MessageDTO {
    message: string;
}
