"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageDTO = void 0;
class MessageDTO {
}
exports.MessageDTO = MessageDTO;
//# sourceMappingURL=message.dto.js.map