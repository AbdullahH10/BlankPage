export declare class ResponseDTO {
    status: string;
    data: any;
    constructor(status: string, data: any);
}
