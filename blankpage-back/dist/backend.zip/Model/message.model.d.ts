export declare class Message {
    timestamp: Date;
    message: string;
}
