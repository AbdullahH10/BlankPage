"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Message = void 0;
class Message {
}
exports.Message = Message;
//# sourceMappingURL=message.model.js.map